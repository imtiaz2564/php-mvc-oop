-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `sportsmvc` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `sportsmvc`;

DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `login` (`username`, `password`) VALUES
('imtiaz2564',	'8604129eabb001921bd13b914fecb29e');

DROP TABLE IF EXISTS `sports`;
CREATE TABLE `sports` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sports` (`id`, `category`, `name`) VALUES
(1,	'test',	'test'),
(2,	'test',	'test'),
(3,	'new',	'new'),
(6,	'test',	'test');

-- 2020-10-23 15:26:38
